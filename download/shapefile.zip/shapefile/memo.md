* 国土数値情報　ダウンロードサービス
    - http://nlftp.mlit.go.jp/ksj/index.html

北海道のデータ

* 国土数値情報　行政区域データ (N03-170101_01_GML)
    - http://nlftp.mlit.go.jp/ksj/gml/datalist/KsjTmplt-N03-v2_3.html
* 国土数値情報　小学校区データ (A27-16_01_GML)
    - http://nlftp.mlit.go.jp/ksj/gml/datalist/KsjTmplt-A27-v2_1.html
* 国土数値情報　公共施設データ (P02-06_01_GML)
    - http://nlftp.mlit.go.jp/ksj/gml/datalist/KsjTmplt-P02-v4_0.html
* 国土数値情報　バス停留所データ (P11-10_01_GML)
    - http://nlftp.mlit.go.jp/ksj/gml/datalist/KsjTmplt-P11.html
